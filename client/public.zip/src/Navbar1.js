import React from "react";
import {
  FaFacebookF,
  FaYoutube,
  FaLinkedinIn,
  FaInstagram,
  FaTwitter,
} from "react-icons/fa";
import { IoIosMail, IoIosCall } from "react-icons/io";
export default function Navbar1() {
  return (
    <div>
      
    </div>
  )
}
