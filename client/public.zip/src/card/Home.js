import React, { useEffect, useState, useContext } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Card, Button } from "react-bootstrap"; // Import Card and Button
import { Link } from "react-router-dom"; // Import Link

import "./Home.css";
// import "./Home.css";

const Home = () => {
  const [currentNameIndex, setCurrentNameIndex] = useState(0);
  const [staycations, setStaycations] = useState([]);
  const names = ["Experience", " Unique", " For You"];

  const [currentSlide, setCurrentSlide] = useState(0);

  const totalSlides = 6; // Number of slides

  const handleNext = () => {
    setCurrentSlide((prevSlide) => (prevSlide + 1) % (totalSlides + 1));
  };

  const handlePrev = () => {
    setCurrentSlide(
      (prevSlide) => (prevSlide - 1 + totalSlides + 1) % (totalSlides + 1)
    );
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setCurrentNameIndex((prevIndex) => (prevIndex + 1) % names.length);
    }, 2000);

    return () => clearTimeout(timeoutId);
  }, [currentNameIndex, names]);

  useEffect(() => {
    // Fetch staycation data from your server
    const accessToken = localStorage.getItem("yourTokenKey"); // Replace 'your-access-token' with your actual access token

    fetch("http://localhost:5000/api/staycation/fetchData", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        console.log("Fetched data:", data);
        setStaycations(data);
      })
      .catch((error) => console.error("Error fetching staycations:", error));
  }, []);

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div
            style={{
              position: "relative",
              textAlign: "center",
            }}
          >
            <img
              src="images/home.webp"
              alt=""
              className="img-fluid"
              style={{
                float: "right",
                maxWidth: "70%",
              }}
            />
            <div
              style={{
                position: "absolute",
                textAlign: "left",
                width: "50%",
                marginTop: "1rem",
              }}
            >
              <h1
                style={{
                  fontSize: "80px",
                  marginTop: "17%",
                  marginLeft: "20%",
                  color: "black",
                  fontFamily: "Open Sans",
                  font: "Open Sans",
                  width: "100%",
                }}
              >
                Stays that are
              </h1>
              <span
                style={{
                  position: "relative",
                  fontSize: "70px",
                  fontFamily: "Libre Bodoni, serif",
                  font: "serif",
                  marginLeft: "20%",
                  fontStyle: "italic",
                }}
              >
                {names[currentNameIndex]}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* location slider */}
      <div className="container-fluid" style={{
    marginBottom:"2pc",paddingBottom:"1pc",paddingTop:"2pc",backgroundColor:"#f6f5f4"}}>
        <h1
          style={{
            fontFamily: "Marcellus, serif",
            font: "Marcellus-300",
          }}
        >
          Browse By
          <span
            style={{
              fontFamily: "Marcellus, serif",
              font: "Marcellus-300",
              color: "#fc6b03",
            }}
          >
            Loaction
          </span>
        </h1>

        <div className="slider-container">
          <div
            className="slider-wrapper"
            style={{
              transform: `translateX(${-currentSlide * (100 / totalSlides)}%)`,
            }}
          >
            <div className="slider-slide">
              <img src="images/image1.webp" alt="Slide 1" />
            </div>
            <div className="slider-slide">
              <img src="images/image2.webp" alt="Slide 2" />
            </div>
            <div className="slider-slide">
              <img src="images/image3.webp" alt="Slide 3" />
            </div>
            <div className="slider-slide">
              <img src="images/image4.webp" alt="Slide 4" />
            </div>
            <div className="slider-slide">
              <img src="images/image5.webp" alt="Slide 5" />
            </div>
            <div className="slider-slide">
              <img src="images/image5.webp" alt="Slide 6" />
            </div>
          </div>
          <button className="slider-button-prev" onClick={handlePrev}>
            Prev
          </button>
          <button className="slider-button-next" onClick={handleNext}>
            Next
          </button>
        </div>
      </div>

      {/* card */}
      <div className="container-fluid">
        <h1
          className="container-fluid"
          style={{
            fontFamily: "Marcellus, serif",
            font: "Marcellus-300",
          }}
        >
          Most views
          <span
            className="container-fluid"
            style={{
              fontFamily: "Marcellus, serif",
              font: "Marcellus-300",
              color: "#fc6b03",
            }}
          >
            Properties
          </span>
        </h1>

        <Container className="mt-5">
          <Row>
            {staycations.map((staycation) => (
              <Col key={staycation._id} xs={12} sm={6} md={4} lg={3}>
                <Card className="mb-4" style={{ objectFit: "contain" }}>
                  <Link to={`/property/${staycation._id}`}>
                    <Card.Img
                      variant="top"
                      src={staycation.imageSrc[0]}
                      style={{ objectFit: "cover" }}
                    />
                  </Link>
                  <Card.Body style={{ height: "160px" }}>
                    <Card.Title>
                      {staycation.title}{" "}
                      <p className="fs-6 text-secondary fw-normal">
                        {staycation.location}
                      </p>
                    </Card.Title>
                    <div className="d-flex flex-row mb-2">
                      <Card.Text>
                        <span
                          style={{
                            fontSize: "15px",
                            marginTop: "-5px",
                          }}
                          className="d-flex flex-row mb-1"
                        >
                          <p
                            style={{ fontSize: "13px" }}
                            className="fw-bold text-secondary me-1"
                          >
                            FROM{" "}
                          </p>
                          <p
                            style={{
                              color: "#fc6b03",
                              fontFamily: "Montserrat, sans-serif",
                              font: "Montserrat-700",
                            }}
                          >
                            ₹{staycation.price}
                          </p>
                          <p
                            style={{ fontSize: "13px" }}
                            className="fw-bold text-secondary"
                          >
                            / Night
                          </p>
                        </span>
                        <p style={{ fontSize: "11px", marginTop: "-24px" }}>
                          (excl. taxes & charger)
                        </p>
                      </Card.Text>
                      <Button
                        style={{
                          fontSize: "15px",
                          color: "#fc6b03",
                          backgroundColor: "white",
                          borderColor: "#fc6b03",
                          width: "100px",
                          height: "35px",
                          marginLeft: "2rem",
                          marginTop: "-6px",
                        }}
                      >
                        Book Now
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </div>
    </div>
  );
};

export default Home;
